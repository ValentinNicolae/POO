#include "Game.h"

void Game::eraseHunter(const unsigned& index) {
	Position pos = hunters[index]->getPosition();
	char symbol = hunters[index]->getSymbol();

	//se elimina cautatorul de pe harta
	map.setChar(pos, ' ');

	//se elmina cautatorul din vectorul de cautatori
	hunters.erase(hunters.begin() + index);
	steps.erase(steps.begin() + index);

	std::cout << "Agentul " << symbol << " de pe pozitia " << pos << "a fost eliminat \n";


}

Game::Game(const unsigned& width, const unsigned& height) : round(0), map(width, height)
{
	std::cout << " Configuratia initiala este \n";
	std::cout << map;
}

void Game::operator()() {
	bool keep_playing = true;
	char input;
	do {
		round++;
		std::cout << "Runda " << round << "\n";
		for (unsigned i = 0; i < hunters.size(); i++) {
			//mutam toti toti cautatorii
			Position pos = hunters[i]->getPosition();
			Position new_pos = hunters[i]->nextMove(map.extract(pos, 3), map.extractPosition(pos, 3));
			//daca cautatorii se misca
			if (pos != new_pos) {
				//resetam nr de pasi consecutivi in care nu s a mutat
				steps[i] = 0;
				//executam mutarea
				try {
					map.setChar(pos, ' ');
					map.setChar(new_pos, hunters[i]->getSymbol());
					hunters[i]->advance(new_pos);

					std::cout << "cautatorul " << hunters[i]->getSymbol() << " s-a mutat din " <<
						pos << " in " << new_pos << "\n";
				}
				//cautatorul a iesit de pe harta si il eliminam
				catch (std::exception e) {
					eraseHunter(i);
					i--;
				}
			}
			else {
				//daca cautatorii nu se misca
				std::cout << " cautatorul " << hunters[i]->getSymbol() << " de pe pos " <<
					pos << " nu s-a mutat \n";
			}
			



			for (unsigned i = 0; i < generators.size(); i++) {
				//faza de generare
				Hunter* hunter = generators[i]->generate(round);
				if (agent != nullptr) {
					Position pos = agent->getPosition();
				}
			}
		}
	}
}

Game::~Game()
{
	std::cout << " \n Jocul s-a sfarsit!";

}
