#include "Generator.h"

Hunter* Generator::spawnHunter() const {
	int type = rand() % 4;
	switch (type) {
	case 0: {
		return new HunterA(getPosition());
		break;
		}
	case 1: {
		return new HunterB(getPosition());
		break;
		}
	case 2: {
		return new HunterC(getPosition());
		break;
		}
	}
	return new HunterD(getPosition());

}

//\
Generator::Generator(const Position& pos, const char& sym) : MapObject(pos, sym) {
//}

Generator::~Generator(){}

//GeneratorA::GeneratorA(const Position& pos) : Generator(pos, 'A'){}

bool GeneratorA::upLeft(const unsigned& w, const unsigned& h) const {
	return w == 0 && h == 0;
}

Hunter* GeneratorA::generate(const Position& pos) const {
	if (!(upLeft(pos.first, pos.second)))
		return nullptr;

	Hunter* hunter = spawnHunter();
	return hunter;
}

//GeneratorB::GeneratorB(const Position& pos) : Generator(pos, 'B'){}

bool GeneratorB::upRight(const unsigned& w, const unsigned& h)const {
	return w == 0 && h == (height - 1);
}

Hunter* GeneratorB::generate(const Position& pos) const {
	if (!(upRight(pos.first, pos.second)))
		return nullptr;

	Hunter* hunter = spawnHunter();
	return hunter;
}

//GeneratorC::GeneratorC(const Position& pos) : Generator(pos, 'C'){}

bool GeneratorC::botLeft(const unsigned& w, const unsigned& h) const {
	return w == (width - 1) && h == 0;
}

Hunter* GeneratorC::generate(const Position& pos) const {
	if (!(botLeft(pos.first, pos.second)))
		return nullptr;

	Hunter* hunter = spawnHunter();
	return hunter;
}

//GeneratorD::GeneratorD(const Position& pos) : Generator(pos, 'D'){}

bool GeneratorD::botRight(const unsigned& w, const unsigned& h) const {
	return w == (width - 1) && h == (height - 1);
}

Hunter* GeneratorD::generate(const Position& pos) const {
	if (!(botRight(pos.first, pos.second)))
		return nullptr;

	Hunter* hunter = spawnHunter();
	return hunter;
}

Treasure::Treasure(const Position& pos) : position(pos.first, pos.second) {}

void Treasure::generateT(const Position& pos) const{
	if (isEmpty(pos) && !(isAllowed))
		return;
	int z1, z2;
	srand(time(nullptr));
	for (unsigned i = 0; i < 3; i++) {
		z1 = rand() % width + 1;
		z2 = rand() % height + 1;
		matrix[z1][z2] = 4;
	}
}

bool Treasure::isAllowed(const unsigned& w, const unsigned& h) {
	return  (w != 0 && h != 0) && (w != 0 && h != (height - 1))
			&& (w != (width - 1) && h != 0) && 
			(w != (width - 1) && h != (height - 1));
}
