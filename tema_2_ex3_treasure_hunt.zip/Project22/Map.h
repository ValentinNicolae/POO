#pragma once
#include <iostream>
#include <stdexcept>
#include <algorithm>

#include "utility.h"
#include "MapObject.h"
class Map : public MapObject
{
protected:
	char** matrix;
	unsigned width, height;
public:
	//constructor
	Map(const unsigned& = 1, const unsigned& = 1);

	//constructor de copiere
	Map(const Map&);

	//supraincarcarea operatorului de atribuire
	Map operator =(const Map&);

	//metoda ce seteaza pozitia data de primul parametru
	//caracterul primit de al treilea parametru
	void setChar(const Position&, const char&);

	//metoda ce seteaza pozitia data de primul parametru
	//itemul primit de al treilea parametru
	void setTreasure(const Position&, const unsigned&);

	//metoda ce returneaza o noua harta ce contine submatrice patrtica centrata in
	//linia si coloana date de primii 2 parametrii si de dimensiune celui de-al 3 lea parametru
	const Map extract(const Position&, const unsigned&) const;

	//metoda ce intoarce pozitia relativa la harta extrasa cu metoda de extract 
	Position extractPosition(const Position&, const unsigned&) const;

	const unsigned getWidth() const;
	const unsigned getHeight() const;

	//metoda ce verifica daca se afla ceva pe o pozitie din harta
	bool isEmpty(const Position&) const;

	// supraincarcarea operatorului << 
	friend std::ostream& operator<<(std::ostream&, const Map&);

	//destructor 
	~Map();

};