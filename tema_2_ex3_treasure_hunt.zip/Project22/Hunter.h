#pragma once
#include "Map.h"
#include "utility.h"
#include "MapObject.h"


class Hunter : public MapObject
{
public:
	Hunter(const Position & = { 0 , 0 }, const char& = 'a');
	virtual Position nextMove(const Map&, const Position&) = 0;
	void advance(const Position&);
	virtual ~Hunter();
};

class HunterA : public Hunter {
public:
	HunterA(const Position & = { 0, 0 });
	Position nextMove(const Map&, const Position&);
};

class HunterB : public Hunter {
public:
	HunterB(const Position & = { 0, 0 });
	Position nextMove(const Map&, const Position&);
};

class HunterC : public Hunter {
	int previous;
public:
	HunterC(const Position & = { 0, 0 });
	Position nextMove(const Map&, const Position&);
};

class HunterD : public Hunter {
	int previous;
public:
	HunterD(const Position & = { 0, 0 });
	Position nextMove(const Map&, const Position&);
};