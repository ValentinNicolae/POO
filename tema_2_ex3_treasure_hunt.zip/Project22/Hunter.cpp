#include "Hunter.h"

Hunter::Hunter(const Position& pos, const char& sym) : MapObject(pos, sym) {
}

void Hunter::advance(const Position& new_position) {
	setPosition(new_position);
}

Hunter::~Hunter() {}

HunterA::HunterA(const Position& pos) : Hunter(Position(pos.first - 1, pos.second), 'a') {
}

Position HunterA::nextMove(const Map& map, const Position& pos) {
	Position new_pos(pos.first - 1, pos.second);
	Position position = getPosition();
	Position ret_position(position.first - 1, position.second);

	try {
		if (map.isEmpty(new_pos))
			return ret_position;
		new_pos = Position(pos.first, pos.second + 1);
		ret_position = Position(position.first, position.second + 1);
		if (map.isEmpty(new_pos))
			return ret_position;
		return position;
	}
	catch (std::exception e) {}
	return ret_position;
}

HunterB::HunterB(const Position& pos) : Hunter(Position(pos.first - 1, pos.second), 'b') {
}

Position HunterB::nextMove(const Map& map, const Position& pos) {
	Position new_pos(pos.first + 1, pos.second);
	Position position = getPosition();
	Position ret_position(position.first + 1, position.second);

	try {
		if (map.isEmpty(new_pos))
			return ret_position;
		return position;
	}
	catch (std::exception e) {}
	return ret_position;
}

HunterC::HunterC(const Position& pos) : Hunter(Position(pos.first, pos.second + 1), 'c'), previous(-1) {

}

Position HunterC::nextMove(const Map& map, const Position& pos) {
	previous *= -1;
	Position new_pos(pos.first + previous, pos.second + 1);
	Position position = getPosition();
	Position ret_position(position.first + previous, position.second + 1);

	try {
		if (map.isEmpty(new_pos))
			return ret_position;
		new_pos = Position(new_pos.first + 1, new_pos.second);
		new_pos = Position(ret_position.first + 1, ret_position.second);

		if (map.isEmpty(new_pos))
			return ret_position;
		previous *= -1;
		return position;
	}
	catch (std::exception e) {}
	return ret_position;
}

HunterD::HunterD(const Position& pos) :Hunter(Position(pos.first, pos.second - 1), 'd'), previous(-1) {

}

Position HunterD::nextMove(const Map& map, const Position& pos) {
	previous *= -1;
	Position new_pos(pos.first + previous, pos.second - 1);
	Position position = getPosition();
	Position ret_position(pos.first + previous, pos.second - 1);

	try {
		if (map.isEmpty(new_pos))
			return ret_position;
		previous *= -1;
		return position;
	}
	catch (std::exception e) {}

	previous *= -1;
	return ret_position;
}
