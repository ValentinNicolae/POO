#pragma once
#include "utility.h"

class MapObject
{
	Position position;
	char symbol;
	unsigned treasure;
protected:
	void setPosition(const Position&);
public:
	MapObject(const Position & = { 0,0 }, const char& = '*', const unsigned& = 0);
	Position getPosition() const;
	char getSymbol();
	unsigned getTreasure();
};

