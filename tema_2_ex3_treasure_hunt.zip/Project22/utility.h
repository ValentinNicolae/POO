#pragma once
#include <ostream>
#include <vector>
#include <utility>

class Hunter;
class Generator;

typedef std::pair<unsigned, unsigned> Position;
typedef std::vector<Generator*>Generators;
typedef std::vector<Hunter*>Hunters;
typedef std::vector<Position>Positions;
typedef std::vector<unsigned>WaitSteps;
typedef std::vector<unsigned>Treasure;

std::ostream& operator<<(std::ostream&, const Position&);
bool operator ==(const Position&, const Position&);


