#pragma once

#include <ctime>

#include "utility.h"
#include "MapObject.h"
#include "Hunter.h"
#include "Map.h"

class Generator : public Map
{
protected:
	Hunter* spawnHunter()const;
public:
	//Generator(const Position & = { 0,0 }, const char& = 'G');
	virtual Hunter* generate(const Position&) const = 0;
	virtual ~Generator() = 0;
};

class GeneratorA : public Generator {
	bool upLeft(const unsigned&, const unsigned&) const;
public:
	//GeneratorA(const Position & = { 0, 0 });
	Hunter* generate(const Position&) const override;
};

class GeneratorB : public Generator {
	bool upRight(const unsigned&, const unsigned&) const;
public:
	//GeneratorB(const Position & = { 0, 0 });
	Hunter* generate(const Position&) const override;
};

class GeneratorC : public Generator {
	bool botLeft(const unsigned&, const unsigned&) const;
public:
	//GeneratorC(const Position & = { 0, 0 });
	Hunter* generate(const Position&) const override;
};

class GeneratorD : public Generator {
	bool botRight(const unsigned&, const unsigned&) const;
public:
	//GeneratorD(const Position & = { 0, 0 });
	Hunter* generate(const Position&) const override;
};

class Treasure : public Generator {
	Position position;
	bool isAllowed(const unsigned&, const unsigned&);
public:
	Treasure(const Position& = { 0, 0 });
	void generateT(const Position&) const;
};
