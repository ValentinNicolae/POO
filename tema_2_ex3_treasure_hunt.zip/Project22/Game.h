#pragma once

#include "utility.h"
#include "Map.h"
#include "Hunter.h"
#include "Generator.h"

class Game {
	Map map;
	unsigned round;
	Generators generators;
	Hunters hunters;
	WaitSteps steps;

	//metoda ce elimina un cautator din joc
	void eraseHunter(const unsigned&);

public:
	Game(const unsigned&, const unsigned&);

	//supraincarcarea operatorului () pt rularea jocului
	void operator() ();
	~Game();
};

