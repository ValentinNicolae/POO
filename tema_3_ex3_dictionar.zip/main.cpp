#include <iostream>
#include <iterator>
#include <map>
using namespace std;
template <typename T>
class Map
{
    const int dimMax;
    const int redim;
    int capCur;
    int dim;
    T *m;
public:
    Map();                              ///constructor fara parametri, care initializeaza un dictionar gol;
    Map(const Map &a);
    Map& operator=(const Map &a);
    T operator[](int poz);             ///exceptie poz>dim
    void inserare(T x);
    void stergere(int poz);            ///stergere dupa pozitie     //exceptie poz>dim
    void afisare();
    int getCapacitate();
    int getDim();
    bool plusCapacitate();             ///exceptie dimMax depasita
    virtual ~Map();
};

class V {

};

class K {

};

template <typename T>
Map<T>::~Map()
{
    delete[]m;
}
int main()
{
    map<int, char> x;
    x.insert(pair<int, char>(2, 'c'));
    x.insert(pair<int, char>(7, 'a'));
    x.insert(pair<int, char>(8, 'b'));
    x.insert(pair<int, char>(4, 't'));
    x.insert(pair<int, char>(3, 'g'));
    x.insert(pair<int, char>(5, 'j'));
    x.insert(pair<int, char>(1, 'w'));
    x.insert(pair<int, char>(6, 'l'));


       // afisare map x
    map<int, char>::iterator itr;
    cout << "\nThe map x is : \n";
    cout << "\tKEY\tELEMENT\n";
    for (itr = x.begin(); itr != x.end(); ++itr) {
        cout << '\t' << itr->first
             << '\t' << itr->second << '\n';
    }
    cout << endl;


    return 0;
}
