#ifndef HARTA_H
#define HARTA_H


class Harta
{
    public:
        Harta();
        virtual ~Harta();

    protected:

    private:
};

#endif // HARTA_H
