#include "Harta.h"

Harta::Harta()
{
    //ctor
}

Harta::~Harta()
{
    //dtor
}
